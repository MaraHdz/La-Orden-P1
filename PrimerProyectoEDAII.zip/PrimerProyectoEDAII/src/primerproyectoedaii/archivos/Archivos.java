/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerproyectoedaii.archivos;

/**
 *
 * @author abreg
 */
public class Archivos {
    //public static ArrayList<Alumno> leerArchivo(){
        
    //}
}
