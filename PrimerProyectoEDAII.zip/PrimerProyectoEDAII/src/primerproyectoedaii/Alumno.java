package primerproyectoedaii;

import java.util.ArrayList;
import java.util.Random;

public class Alumno {
    private String nombre;
    private String apellido;
    private long noCuenta;

    public Alumno(String nom, String ap, long cu){
            nombre = nom;
            apellido = ap;
            noCuenta = cu;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public long getNoCuenta() {
        return noCuenta;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public void setApellido(String Apellido) {
        this.apellido = Apellido;
    }

    public void setNoCuenta(long NoCuenta) {
        this.noCuenta = NoCuenta;
    }
    
    @Override
    public String toString(){
        return noCuenta+" "+apellido+", "+nombre;
    }
    
    public static ArrayList<Alumno> generarLista(int cantidad){
        ArrayList<Alumno> lista = new ArrayList<>();
        Random rand = new Random();
        int inom, iap;
        long num_cuenta;
        String nombres[] = {"Juan","Jose Luis","Jose","Maria Guadalupe","Francisco","Guadalupe","Maria","Juana","Antonio","Jesus","Miguel Angel","Pedro","Alejandro","Manuel","Margarita","Maria Del Carmen","Juan Carlos","Roberto","Fernando","Daniel","Carlos","Jorge","Ricardo","Miguel","Eduardo","Javier","Rafael","Martin","Raul","David","Josefina","Jose Antonio","Arturo","Marco Antonio","Jose Manuel","Francisco Javier","Enrique","Veronica","Gerardo","Maria Elena","Leticia","Rosa","Mario","Francisca","Alfredo","Teresa","Alicia","Maria Fernanda","Sergio","Alberto","Luis","Armando","Alejandra","Martha","Santiago","Yolanda","Patricia","Maria De Los Angeles","Juan Manuel","Rosa Maria","Elizabeth","Gloria","Angel","Gabriela","Salvador","Victor Manuel","Silvia","Maria De Guadalupe","Maria De Jesus","Gabriel","Andres","Oscar","Guillermo","Ana Maria","Ramon","Maria Isabel","Pablo","Ruben","Antonia","Maria Luisa","Luis Angel","Maria Del Rosario","Felipe","Jorge Jesus","Jaime","Jose Guadalupe","Julio Cesar","Jose De Jesus","Diego","Araceli","Andrea","Isabel","Maria Teresa","Irma","Carmen","Lucia","Adriana","Agustin","Maria De La Luz","Gustavo"};
        String apellidos[] = {"Garcia","Gonzalez","Rodriguez","Fernandez","Lopez","Martinez","Sanchez","Perez","Gomez","Martin","Jimenez","Ruiz","Hernandez","Diaz","Moreno","Alvarez","Mu?oz","Romero","Alonso","Gutierrez","Navarro","Torres","Dominguez","Vazquez","Ramos","Gil","Ramirez","Serrano","Blanco","Suarez","Molina","Morales","Ortega","Delgado","Castro","Ortiz","Rubio","Marin","Sanz","Nu?ez","Iglesias","Medina","Garrido","Santos","Castillo","Cortes","Lozano","Guerrero","Cano","Prieto","Mendez","Calvo","Cruz","Gallego","Vidal","Leon","Herrera","Marquez","Pe?a","Cabrera","Flores","Campos","Vega","Diez","Fuentes","Carrasco","Caballero","Nieto","Reyes","Aguilar","Pascual","Herrero","Santana","Lorenzo","Hidalgo","Montero","Iba?ez","Gimenez","Ferrer","Duran","Vicente","Benitez","Mora","Santiago","Arias","Vargas","Carmona","Crespo","Roman","Pastor","Soto","Saez","Velasco","Soler","Moya","Esteban","Parra","Bravo","Gallardo","Rojas"};
        
        for(int i=0; i < cantidad; i++){
            inom = rand.nextInt(99);
            iap = rand.nextInt(99);
            num_cuenta = rand.nextInt(10000000)+((1+ rand.nextInt(9))*10000000);
            
            lista.add(new Alumno(nombres[inom], apellidos[iap], num_cuenta));
        }
        
        
        return lista;
    }
    
    public static void imprimirLista(ArrayList<Alumno> lista){
        for (Alumno alu_act : lista){
            System.out.println(alu_act.toString());
        }
            
    }
    
    
}
