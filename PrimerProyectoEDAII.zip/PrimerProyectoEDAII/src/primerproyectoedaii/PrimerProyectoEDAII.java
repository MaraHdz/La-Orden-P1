/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerproyectoedaii;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author abreg
 */
public class PrimerProyectoEDAII {

    public static void main(String[] args) {
        ArrayList<Alumno> lista;
        lista = Alumno.generarLista(100);
        Alumno.imprimirLista(lista);
        
    }
    
}

/*String fileName = "text2.txt";
        //List<Alumno> names = new ArrayList<>();
        String nombres[] = new String[100];
        int i = 0;

        try (Scanner scan = new Scanner(new File(fileName))) {
            while (scan.hasNext()){
                nombres[i] = scan.nextLine();
                i++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        for(int ij = 0; ij < 100; ij++){
            System.out.print("\""+nombres[ij]+"\",");
        }*/